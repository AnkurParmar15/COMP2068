
const prompt = require('prompt');

prompt.start();

console.log("Let's play Rock-Paper-Scissors!");
console.log("Choose ROCK, PAPER, or SCISSORS.");


prompt.get(['selection'], function (err, result) {
  if (err) {
    console.error('Error occurred:', err);
    return;
  }

  
  const userSelection = result.selection.toUpperCase();
  

  const randomNumber = Math.random();
  let computerSelection;
  if (randomNumber < 0.33) {
    computerSelection = 'ROCK';
  } else if (randomNumber < 0.66) {
    computerSelection = 'PAPER';
  } else {
    computerSelection = 'SCISSORS';
  }


  console.log("You chose:", userSelection);
  console.log("Computer chose:", computerSelection);


  let outcome;
  if (userSelection === computerSelection) {
    outcome = "It's a tie!";
  } else if (
    (userSelection === 'ROCK' && computerSelection === 'SCISSORS') ||
    (userSelection === 'PAPER' && computerSelection === 'ROCK') ||
    (userSelection === 'SCISSORS' && computerSelection === 'PAPER')
  ) {
    outcome = 'You win!';
  } else {
    outcome = 'Computer wins!';
  }

  console.log(outcome);
});
